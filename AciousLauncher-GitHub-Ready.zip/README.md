# Acious Launcher — Fast Client 1.0 Android source

This is an original Kotlin + Jetpack Compose configuration companion prototype.

## Included
- Futuristic dark gaming UI.
- Ultra Light, Balanced and Visual performance profiles.
- Suggested Minecraft video settings per profile.
- Sodium, Lithium and FerriteCore planning checklist.
- JVM memory planning slider.
- Explicit status messaging that settings are not automatically applied.

## Not included yet
- Minecraft Java runtime or game launching.
- Microsoft account authentication.
- Minecraft version/asset downloads.
- Mod downloading, verification or installation.
- Automatic editing of Minecraft options.txt.
- FPS measurement or guaranteed FPS improvements.

The mod checklist is intentionally informational. Mod compatibility changes by Minecraft version and mod loader; verify each mod's official release page for the exact target version before installing. Sodium is a renderer mod; Lithium optimizes game logic; FerriteCore targets memory usage. They are not universal one-click FPS boosts and may have compatibility constraints.

## Build APK
1. Open this folder in Android Studio.
2. Install Android SDK 35 and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Device safety
Do not allocate all physical RAM to Minecraft. Start conservatively, test stability, and close unnecessary background apps. The slider in this prototype is only a planner and does not alter the Java process.

## License and integration
Do not copy proprietary MJLauncher code or branding. For a full Java launcher, review the current PojavLauncher source and license and integrate only through a permitted approach. Minecraft/Microsoft authentication must use a legitimate supported flow; never request a user's Microsoft password directly.

## Build APK automatically on GitHub
This project includes `.github/workflows/android-apk.yml`.

1. Create a GitHub repository and upload the extracted project files (not just the ZIP).
2. Open the repository's Actions tab and run **Build Acious Launcher APK** with **Run workflow**.
3. Download `acious-launcher-debug-apk` from the completed workflow run.
4. To create a GitHub Release with the APK attached, push a version tag such as `v1.0.0`.

The output is a debug/test APK, not a signed production release. The app remains a configuration companion prototype, not a full Minecraft launcher.
